// header files

#ifndef DICTIONARY_HPP
#define DICTIONARY_HPP
#include <string>
// name space
namespace sdds
{
  // dictionary class
  class Dictionary
  {
    std::string m_term{};
    std::string m_definition{};

  public:
    const std::string &getTerm() const { return m_term; }
    const std::string &getDefinition() const { return m_definition; }
    Dictionary(const std::string &term, const std::string &definition) : m_term{term}, m_definition{definition} {}
    // dictionary constructor
    Dictionary();
    bool operator==(const Dictionary &obj);
    friend std::ostream &operator<<(std::ostream &out, const Dictionary &obj);
  };
}

#endif
