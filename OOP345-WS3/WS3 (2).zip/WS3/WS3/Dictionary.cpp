// header files
#include "Dictionary.h"
#include <iomanip>
// name space
namespace sdds
{
    // Dictionary constructor
    Dictionary::Dictionary()
    {
    }

    bool Dictionary::operator==(const Dictionary &obj)
    {
        return (m_term == obj.m_term && m_definition == obj.m_definition);
    }

    std::ostream &operator<<(std::ostream &out, const Dictionary &obj)
    {
        out << std::setw(20) << std::right << obj.getTerm() << ": " << obj.getDefinition();
        return out;
    }

}
