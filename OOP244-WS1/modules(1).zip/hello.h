#ifndef HELLO_H
#define HELLO_H 

namespace mars {

    // a constant
    const int x = 12345;

    //a function prototype
    int foo(const char *);
}

#endif
