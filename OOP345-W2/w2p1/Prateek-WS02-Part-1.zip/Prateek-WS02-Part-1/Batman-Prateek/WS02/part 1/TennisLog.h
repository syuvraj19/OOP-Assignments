#ifndef SDDS_TENNISLOG_H
#define SDDS_TENNISLOG_H
#include <iostream>
namespace sdds
{
    struct TennisMatch
    {
        int m_match_id;
        char *m_winner;
        char *m_loser;
        char *m_tournament_name;
        char *m_tournament_id;
        TennisMatch();
        TennisMatch(const char *tourney_id, const char *tourney_name, int tourney_match_id, const char *tourney_winner, const char *tourney_loser);
        friend std::ostream &operator<<(std::ostream &out, const TennisMatch &match);
    };
    class TennisLog
    {
        TennisMatch *m_matches;
        size_t m_num_of_matches;

    public:
        TennisLog();
        operator size_t() const;
        TennisMatch operator[](size_t);
        TennisLog(const char *file_name);
        void addMatch(const TennisMatch &match);
        TennisLog findMatches(const char *player_name) const;
        ~TennisLog();
    };
}
#endif