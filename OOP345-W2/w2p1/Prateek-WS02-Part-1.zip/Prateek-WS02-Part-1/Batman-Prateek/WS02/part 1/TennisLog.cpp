#include <fstream>
#include <cstring>
#include <iomanip>
#include "TennisLog.h"
using namespace std;
namespace sdds
{
    TennisMatch::TennisMatch()
    {
        m_tournament_id = nullptr;
        m_tournament_name = nullptr;
        m_match_id = 0;
        m_winner = nullptr;
        m_loser = nullptr;
    }
    TennisMatch::TennisMatch(const char *tourney_id, const char *tourney_name, int tourney_match_id, const char *tourney_winner, const char *tourney_loser)
    {
        m_match_id = tourney_match_id;
        m_tournament_id = new char[strlen(tourney_id) + 1];
        strcpy(m_tournament_id, tourney_id);
        m_tournament_name = new char[strlen(tourney_name) + 1];
        strcpy(m_tournament_name, tourney_name);
        m_winner = new char[strlen(tourney_winner) + 1];
        strcpy(m_winner, tourney_winner);
        m_loser = new char[strlen(tourney_loser) + 1];
        strcpy(m_loser, tourney_loser);
    }
    ostream &operator<<(ostream &out, const TennisMatch &match)
    {
        if (match.m_tournament_id != nullptr)
        {
            out << setw(20) << setfill('.') << right
                << "Tourney ID"
                << " : " << setw(30) << setfill('.')
                << left << match.m_tournament_id << endl;
            out << setw(20) << setfill('.') << right
                << "Match ID"
                << " : " << setw(30) << setfill('.')
                << left << match.m_match_id << endl;
            out << setw(20) << setfill('.') << right
                << "Tourney"
                << " : " << setw(30) << setfill('.')
                << left << match.m_tournament_name << endl;
            out << setw(20) << setfill('.') << right
                << "Winner"
                << " : " << setw(30) << left
                << match.m_winner << endl;
            out << setw(20) << setfill('.') << right
                << "Loser"
                << " : " << setw(30) << left
                << match.m_loser << endl;
        }
        else
        {
            out << "Empty Match";
        }
        return out;
    }
    TennisLog::TennisLog()
    {
        m_matches = nullptr;
        m_num_of_matches = 0;
    }
    TennisLog::operator size_t() const
    {
        return m_num_of_matches;
    }
    TennisMatch TennisLog::operator[](size_t n)
    {
        TennisMatch t;
        if (m_num_of_matches >= 1)
        {
            t = m_matches[n];
        }
        return t;
    }
    TennisLog::TennisLog(const char *file_name)
    {
        ifstream f(file_name);
        string l;
        int c = 0;
        if (f.is_open())
        {
            while (getline(f, l))
            {
                c++;
            }
            m_num_of_matches = c - 1;
            m_matches = new TennisMatch[m_num_of_matches];
            f.clear();
            f.seekg(0);
            getline(f, l);
            for (size_t i = 0; i < m_num_of_matches; i++)
            {
                getline(f, l, ',');
                m_matches[i].m_tournament_id = new char[l.length() + 1];
                strcpy(m_matches[i].m_tournament_id, l.c_str());
                getline(f, l, ',');
                m_matches[i].m_tournament_name = new char[l.length() + 1];
                strcpy(m_matches[i].m_tournament_name, l.c_str());
                getline(f, l, ',');
                m_matches[i].m_match_id = stoi(l);
                getline(f, l, ',');
                m_matches[i].m_winner = new char[l.length() + 1];
                strcpy(m_matches[i].m_winner, l.c_str());
                getline(f, l);
                m_matches[i].m_loser = new char[l.length() + 1];
                strcpy(m_matches[i].m_loser, l.c_str());
            }
            f.close();
        }
    }
    void TennisLog::addMatch(const TennisMatch &match)
    {
        if (m_matches != nullptr)
        {
            TennisMatch *t = new TennisMatch[m_num_of_matches + 1];
            for (size_t i = 0; i < m_num_of_matches; i++)
            {
                t[i] = m_matches[i];
            }
            t[m_num_of_matches] = match;
            delete[] m_matches;
            m_matches = t;
            m_num_of_matches++;
        }
        else
        {
            m_matches = new TennisMatch[1];
            m_matches[0] = match;
            m_num_of_matches = 1;
        }
    }
    TennisLog TennisLog::findMatches(const char *player_name) const
    {
        TennisLog t;
        for (size_t i = 0; i < m_num_of_matches; i++)
        {
            if (strcmp(m_matches[i].m_loser, player_name) == 0 || strcmp(m_matches[i].m_winner, player_name) == 0)
            {
                TennisMatch match(m_matches[i].m_tournament_id, m_matches[i].m_tournament_name, m_matches[i].m_match_id, m_matches[i].m_winner, m_matches[i].m_loser);
                t.addMatch(match);
            }
        }
        return t;
    }
    TennisLog::~TennisLog()
    {
        for (size_t i = 0; i < m_num_of_matches; i++)
        {
            delete[] m_matches[i].m_tournament_id;
            delete[] m_matches[i].m_tournament_name;
            delete[] m_matches[i].m_winner;
            delete[] m_matches[i].m_loser;
        }
        delete[] m_matches;
    }
}